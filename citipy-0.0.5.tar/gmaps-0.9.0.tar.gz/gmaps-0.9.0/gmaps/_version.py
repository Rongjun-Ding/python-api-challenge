
# This file is generated programatically.

# Version of the Python package
__version__ = '0.9.0'

# Version of the JS client. This must match the version field in package.json.
CLIENT_VERSION = '0.9.0'
